/*
 * The UserProfile class represents the user profile activity in the To-Do List application.
 * This activity allows the user to view their username, points, and equipped avatar items.
 * The user can equip different avatar items if they have been purchased in the PointsShop.
 * The class handles the initialization of the user profile UI, setting up button click listeners
 * for equipping avatar items and navigating back to the main menu, checking if items have been purchased,
 * equipping items, saving the currently equipped item to shared preferences,
 * loading the currently equipped item from shared preferences, and loading the user's current points
 * from shared preferences.
 */

package edu.utsa.cs3443.xsy225_lab3.todolistapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class UserProfile extends AppCompatActivity {

    private TextView usernameTextView;
    private TextView pointsTextView;
    private ImageView userAvatarImageView;
    private static final String SHARED_PREFS_KEY = "shared_prefs";
    private static final String POINTS_KEY = "points";
    private static final String EQUIPPED_ITEM_KEY = "equipped_item";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_profile);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        usernameTextView = findViewById(R.id.Username);
        pointsTextView = findViewById(R.id.pointsTextView);
        userAvatarImageView = findViewById(R.id.UserAvatar);

        Intent intent = getIntent();
        String username = intent.getStringExtra("username");
        if (username != null) {
            usernameTextView.setText(username);
        }

        int points = loadPoints();
        pointsTextView.setText("Points: " + points);

        setupEquipButton(R.id.buttonGreenPenguin, "green_penguin");
        setupEquipButton(R.id.buttonRedTie, "red_tie");
        setupEquipButton(R.id.buttonDefaultPenguin, "default_penguin");
        setupEquipButton(R.id.buttonHarry, "harry_penguin");
        setupEquipButton(R.id.buttonUserGlasses, "glasses_penguin");
        setupEquipButton(R.id.buttonUserCrown, "crown_penguin");
        setupEquipButton(R.id.buttonUserMullet, "penguin_mullet");

        loadEquippedItem();

        Button backButton = findViewById(R.id.button8);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UserProfile.this, Main_Menu.class);
                intent.putExtra("USERNAME", username); // Pass the username back to Main_Menu
                startActivity(intent);
                finish();
            }
        });
    }

    private void setupEquipButton(int buttonId, String itemName) {
        Button button = findViewById(buttonId);
        button.setOnClickListener(v -> {
            if (isItemPurchased(itemName) || itemName.equals("default_penguin")) {
                equipItem(itemName);
                saveEquippedItem(itemName);
            } else {
                // Optionally, notify the user that the item needs to be purchased first
            }
        });
    }

    private boolean isItemPurchased(String itemName) {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        return sharedPreferences.getBoolean(itemName, false);
    }

    private void equipItem(String itemName) {
        int resId = getResources().getIdentifier(itemName, "drawable", getPackageName());
        if (resId != 0) {
            userAvatarImageView.setImageResource(resId);
        } else {
            // Optionally, handle the case where the resource is not found
        }
    }

    private void saveEquippedItem(String itemName) {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(EQUIPPED_ITEM_KEY, itemName);
        editor.apply();
    }

    private void loadEquippedItem() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        String equippedItem = sharedPreferences.getString(EQUIPPED_ITEM_KEY, "default_penguin");
        equipItem(equippedItem);
    }

    private int loadPoints() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        return sharedPreferences.getInt(POINTS_KEY, 0);
    }
}
