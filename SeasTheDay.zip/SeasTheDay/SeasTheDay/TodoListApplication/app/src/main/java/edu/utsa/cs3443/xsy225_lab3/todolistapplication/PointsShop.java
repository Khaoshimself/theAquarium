/*
 * The PointsShop class represents the points shop activity in the To-Do List application.
 * This activity allows the user to spend points earned from completing tasks to purchase items.
 * The class handles the initialization of the points shop UI, setting up button click listeners for purchasing items,
 * updating the displayed points, managing the purchased items state, and saving/loading points and purchased items from shared preferences.
 * The class also prevents the user from purchasing an item if they do not have enough points or if the item has already been purchased.
 */

package edu.utsa.cs3443.xsy225_lab3.todolistapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PointsShop extends AppCompatActivity {

    private static final String SHARED_PREFS_KEY = "shared_prefs";
    private static final String POINTS_KEY = "points";
    private static final int ITEM_COST = 500;

    private int points;
    private TextView pointsTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_points_shop);

        View mainLayout = findViewById(R.id.main);
        if (mainLayout.getBackground() instanceof AnimationDrawable) {
            AnimationDrawable animationDrawable = (AnimationDrawable) mainLayout.getBackground();
            animationDrawable.setEnterFadeDuration(5000);
            animationDrawable.setExitFadeDuration(5000);
            animationDrawable.start();
        }

        pointsTextView = findViewById(R.id.pointsTextview);
        points = loadPoints();
        pointsTextView.setText("Points: " + points);

        Button backButton = findViewById(R.id.button7);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PointsShop.this, Main_Menu.class);
                startActivity(intent);
                finish();
            }
        });

        setupPurchaseButton(R.id.buttonRedTie, "red_tie");
        setupPurchaseButton(R.id.buttonGlasses, "glasses_penguin");
        setupPurchaseButton(R.id.buttonHarryPenguin, "harry_penguin");
        setupPurchaseButton(R.id.buttonMullet, "penguin_mullet");
        setupPurchaseButton(R.id.buttonGreenPenguin, "green_penguin");
        setupPurchaseButton(R.id.buttonCrown, "crown_penguin");
    }

    private void setupPurchaseButton(int buttonId, String itemName) {
        Button button = findViewById(buttonId);
        if (isItemPurchased(itemName)) {
            button.setEnabled(false);
            button.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));
        } else {
            button.setOnClickListener(v -> {
                if (points >= ITEM_COST) {
                    points -= ITEM_COST;
                    button.setEnabled(false);
                    button.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));
                    savePoints();
                    savePurchasedItem(itemName);
                    pointsTextView.setText("Points: " + points);
                    Toast.makeText(PointsShop.this, "Item purchased!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(PointsShop.this, "Not enough points!", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private boolean isItemPurchased(String itemName) {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        return sharedPreferences.getBoolean(itemName, false);
    }

    private void savePurchasedItem(String itemName) {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(itemName, true);
        editor.apply();
    }

    private int loadPoints() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        return sharedPreferences.getInt(POINTS_KEY, 0);
    }

    private void savePoints() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(POINTS_KEY, points);
        editor.apply();
    }
}
