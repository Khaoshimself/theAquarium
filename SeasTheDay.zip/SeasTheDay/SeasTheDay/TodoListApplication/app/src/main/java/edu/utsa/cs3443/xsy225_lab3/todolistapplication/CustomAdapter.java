package edu.utsa.cs3443.xsy225_lab3.todolistapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

/* The CustomAdapter class is a custom ArrayAdapter that handles the display and interaction of to-do list items
 * It extends ArrayAdapter<String> and is used to populate a ListView with to-do items, each with delete and complete buttons.
 * The adapter manages the removal of items and awards points when tasks are marked as complete.
 * It ensures that changes to the to-do list are saved by interacting with the TodoList activity.
 * The class takes a Context and an ArrayList<String> of items as inputs, inflating a custom layout for each item.
 * The layout contains a TextView for the item text and two buttons: one for deleting the item and another for marking it as complete.
 */
public class CustomAdapter extends ArrayAdapter<String> {

    private final ArrayList<String> items;
    private final Context context;

    public CustomAdapter(Context context, ArrayList<String> items) {
        super(context, 0, items);
        this.items = items;
        this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        TextView itemTextView = convertView.findViewById(R.id.itemTextView);
        Button deleteButton = convertView.findViewById(R.id.deleteButton);
        Button completeButton = convertView.findViewById(R.id.CompleteBtn);

        String item = getItem(position);
        itemTextView.setText(item);

        deleteButton.setOnClickListener(v -> {
            items.remove(position);
            notifyDataSetChanged();
            if (context instanceof TodoList) {
                ((TodoList) context).saveItems();
            }
        });

        completeButton.setOnClickListener(v -> {
            items.remove(position);
            notifyDataSetChanged();
            if (context instanceof TodoList) {
                TodoList todoList = (TodoList) context;
                todoList.awardPoints();
                todoList.saveItems();
            }
        });

        return convertView;
    }
}
