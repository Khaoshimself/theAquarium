/*
 * The TodoList class represents the to-do list activity in the To-Do List application.
 * This activity allows the user to add, remove, and view tasks in their to-do list.
 * The user can add tasks using an input field and a button, and remove tasks by long-clicking on them.
 * The class handles the initialization of the to-do list UI, setting up button click listeners for adding tasks and navigating back to the main menu,
 * managing the list of tasks with a custom adapter, saving and loading tasks from shared preferences,
 * awarding points for task completion, and displaying the user's current points.
 */

package edu.utsa.cs3443.xsy225_lab3.todolistapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class TodoList extends AppCompatActivity {

    private static final String SHARED_PREFS_KEY = "shared_prefs";
    private static final String ITEMS_KEY = "items";
    private static final String POINTS_KEY = "points";
    private static final int POINTS_PER_TASK = 500;

    private ArrayList<String> items;
    private CustomAdapter itemsAdapter;
    private ListView listView;
    private Button addButton;
    private Button backButton;
    private EditText inputEditText;
    private TextView pointsTextView;
    private int points;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_todo_list);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listView = findViewById(R.id.List);
        addButton = findViewById(R.id.addButton);
        backButton = findViewById(R.id.backButton);
        inputEditText = findViewById(R.id.inputEditText);
        pointsTextView = findViewById(R.id.pointsTextView);

        items = loadItems();
        points = loadPoints();

        itemsAdapter = new CustomAdapter(this, items);
        listView.setAdapter(itemsAdapter);

        pointsTextView.setText("Points: " + points);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addItem(view);
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(TodoList.this, Main_Menu.class);
                intent.putExtra("points", points); // Pass points to the Main Menu
                startActivity(intent);
                finish();
            }
        });

        setUpListViewListener();
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveItems();
        savePoints();
    }

    private void setUpListViewListener() {
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long I) {
                Context context = getApplicationContext();
                Toast.makeText(context, "Item Removed", Toast.LENGTH_LONG).show();

                items.remove(i);
                itemsAdapter.notifyDataSetChanged();
                return true;
            }
        });
    }

    private void addItem(View view) {
        String itemText = inputEditText.getText().toString();
        if (!itemText.isEmpty()) {
            itemsAdapter.add(itemText);
            itemsAdapter.notifyDataSetChanged();
            inputEditText.setText("");
        } else {
            Toast.makeText(this, "Please enter a task", Toast.LENGTH_SHORT).show();
        }
    }

    public void awardPoints() {
        points += POINTS_PER_TASK;
        pointsTextView.setText("Points: " + points);
        savePoints();
    }

    public void saveItems() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Set<String> itemSet = new HashSet<>(items);
        editor.putStringSet(ITEMS_KEY, itemSet);
        editor.apply();
    }

    private ArrayList<String> loadItems() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        Set<String> itemSet = sharedPreferences.getStringSet(ITEMS_KEY, new HashSet<>());
        return new ArrayList<>(itemSet);
    }

    private void savePoints() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(POINTS_KEY, points);
        editor.apply();
    }

    private int loadPoints() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        return sharedPreferences.getInt(POINTS_KEY, 0);
    }
}
