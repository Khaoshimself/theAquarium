package edu.utsa.cs3443.xsy225_lab3.todolistapplication;

public class Penguin {
    private String name;
    private int price;
    private boolean purchased;
/* giving informmation Penguin name, price and when purchased 
 * When penguin is purchased, it will call for that penguin name and register that pegnuin in purchased. This will also grey out the purshase box so that it cannot be purchased again 
 */


    public Penguin(String name, int price) {
        this.name = name;
        this.price = price;
        this.purchased = false;
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public boolean isPurchased() {
        return purchased;
    }

    public void setPurchased(boolean purchased) {
        this.purchased = purchased;
    }
}
