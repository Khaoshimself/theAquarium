package edu.utsa.cs3443.xsy225_lab3.todolistapplication;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/* The Main_menu class is allowing the user to login on the main menu and passing the username to the point shop
 * This is also setting the Welcome "User" to each page
 * It is also making the logout button and returning it to the sign in page
 */
public class Main_Menu extends AppCompatActivity {

    private TextView welcomeTextView;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainLayout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ConstraintLayout constraintLayout = findViewById(R.id.mainLayout);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2500);
        animationDrawable.setExitFadeDuration(5000);
        animationDrawable.start();

        username = getIntent().getStringExtra("USERNAME");

        welcomeTextView = findViewById(R.id.welcomeTextView);
        if (username != null) {
            welcomeTextView.setText("Welcome, " + username + "!");
        }

        Button profileButton = findViewById(R.id.button4);
        profileButton.setOnClickListener(view -> {
            Intent intent = new Intent(Main_Menu.this, UserProfile.class);
            intent.putExtra("username", username); // Pass the username to UserProfile
            startActivity(intent);
        });

        Button todoListButton = findViewById(R.id.button2);
        todoListButton.setOnClickListener(view -> {
            Intent intent = new Intent(Main_Menu.this, TodoList.class);
            intent.putExtra("username", username); // Pass the username to TodoList if needed
            startActivity(intent);
        });

        Button pointsShopButton = findViewById(R.id.button3);
        pointsShopButton.setOnClickListener(view -> {
            Intent intent = new Intent(Main_Menu.this, PointsShop.class);
            intent.putExtra("username", username); // Pass the username to PointsShop if needed
            startActivity(intent);
        });

        Button logoutButton = findViewById(R.id.button5);
        logoutButton.setOnClickListener(view -> {
            Intent intent = new Intent(Main_Menu.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
