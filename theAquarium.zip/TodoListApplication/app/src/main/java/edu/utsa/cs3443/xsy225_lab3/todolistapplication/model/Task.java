package edu.utsa.cs3443.xsy225_lab3.todolistapplication.model;

/**
 * Model representing a task in the todo list.
 * A Task object stores information about the task name and its completion status.
 */
public class Task {
    private String name;
    private boolean completed;

    /**
     * Constructor for Task.
     * @param name The name of the task.
     */
    public Task(String name) {
        this.name = name;
        this.completed = false; // Default to not completed
    }

    /**
     * Gets the name of the task.
     * @return The name of the task.
     */
    public String getName() {
        return name;
    }

    /**
     * Checks if the task is completed.
     * @return True if completed, false otherwise.
     */
    public boolean isCompleted() {
        return completed;
    }

    /**
     * Marks the task as completed.
     */
    public void markAsCompleted() {
        this.completed = true;
    }
}
