package edu.utsa.cs3443.xsy225_lab3.todolistapplication.view;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import edu.utsa.cs3443.xsy225_lab3.todolistapplication.R;

/**
 * Activity for displaying the user's profile information.
 * <p>
 * This activity provides:
 * - Display of points earned.
 * - Display of the number of fish saved (based on points).
 * - Navigation back to the main menu.
 */
public class UserProfileActivity extends AppCompatActivity {

    private static final String SHARED_PREFS_KEY = "shared_prefs"; // Key for SharedPreferences
    private static final String POINTS_KEY = "points_default_user"; // Key for saving/loading points

    private TextView pointsTextView; // TextView to display user points
    private TextView fishSavedTextView; // TextView to display the number of fish saved

    /**
     * Initializes the UserProfileActivity and binds UI elements.
     * <p>
     * Points and fish saved are loaded from SharedPreferences and displayed on the screen.
     * A back button is provided to navigate back to the main menu.
     *
     * @param savedInstanceState The saved instance state for the activity.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        // Bind UI elements
        TextView usernameTextView = findViewById(R.id.usernameTextView);
        usernameTextView.setText("Profile"); // Display "Profile" title

        pointsTextView = findViewById(R.id.pointsTextView);
        fishSavedTextView = findViewById(R.id.fishSavedTextView);
        Button backButton = findViewById(R.id.button8);

        // Load points from SharedPreferences
        int points = loadPoints();

        // Display points and fish saved
        pointsTextView.setText("Points: " + points);
        fishSavedTextView.setText("Fish Saved: " + (points / 1000));

        // Handle back button click
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainMenuActivity.class);
            startActivity(intent);
            finish(); // Close the current activity
        });
    }

    /**
     * Loads the points for the user from SharedPreferences.
     * If no points are saved, the default value is 0.
     *
     * @return The user's current points.
     */
    private int loadPoints() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        return sharedPreferences.getInt(POINTS_KEY, 0); // Default to 0 if no points are saved
    }

    /**
     * Refreshes the points and fish saved display when the activity is resumed.
     * This ensures the display is accurate in case points are updated elsewhere.
     */
    @Override
    protected void onResume() {
        super.onResume();

        // Load updated points
        int points = loadPoints();

        // Update UI elements
        pointsTextView.setText("Points: " + points);
        fishSavedTextView.setText("Fish Saved: " + (points / 1000));
    }
}
