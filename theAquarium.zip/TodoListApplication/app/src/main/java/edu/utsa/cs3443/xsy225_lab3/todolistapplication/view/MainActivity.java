package edu.utsa.cs3443.xsy225_lab3.todolistapplication.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import androidx.appcompat.app.AppCompatActivity;

import edu.utsa.cs3443.xsy225_lab3.todolistapplication.R;

/**
 * MainActivity handles the user login process.
 * Users enter their username, and upon submission, they are navigated to the MainMenuActivity.
 */
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind UI elements
        TextInputEditText usernameEditText = findViewById(R.id.usernameEditText);
        Button loginButton = findViewById(R.id.button);

        // Set up login button click listener
        loginButton.setOnClickListener(view -> {
            String username = usernameEditText.getText().toString().trim();

            if (!username.isEmpty()) {
                Intent intent = new Intent(this, MainMenuActivity.class);
                intent.putExtra("username", username); // Pass username
                startActivity(intent);
                finish(); // Close MainActivity
            } else {
                Toast.makeText(this, "Please enter a username", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
