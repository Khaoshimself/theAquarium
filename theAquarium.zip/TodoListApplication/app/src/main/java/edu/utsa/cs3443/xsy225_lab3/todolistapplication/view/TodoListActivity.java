package edu.utsa.cs3443.xsy225_lab3.todolistapplication.view;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import edu.utsa.cs3443.xsy225_lab3.todolistapplication.R;
import edu.utsa.cs3443.xsy225_lab3.todolistapplication.adapter.CustomAdapter;
import edu.utsa.cs3443.xsy225_lab3.todolistapplication.controller.TodoListController;
import edu.utsa.cs3443.xsy225_lab3.todolistapplication.model.Task;
import edu.utsa.cs3443.xsy225_lab3.todolistapplication.model.User;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * Activity for managing and displaying the user's todo list.
 * <p>
 * This activity allows users to:
 * - Add tasks to their todo list.
 * - Complete tasks to earn points.
 * - Save and load tasks from persistent storage.
 * - Navigate back to the main menu.
 */
public class TodoListActivity extends AppCompatActivity {
    private TodoListController controller; // Controller to handle business logic
    private CustomAdapter adapter;        // Adapter for displaying tasks in a ListView
    private ArrayList<Task> tasks;        // List of tasks for the user

    private TextView pointsTextView;      // TextView to display user points
    private EditText inputEditText;       // EditText for task input
    private ListView listView;            // ListView to display the task list
    private User user;                    // Current user object

    private static final String SHARED_PREFS_KEY = "shared_prefs"; // SharedPreferences key
    private static final String TASKS_KEY = "tasks";               // Key for saving tasks
    private static final String POINTS_KEY = "points_default_user"; // Key for saving user points

    /**
     * Initializes the activity and sets up the todo list.
     * <p>
     * This method binds UI elements, sets up listeners, and loads tasks and points
     * from SharedPreferences.
     *
     * @param savedInstanceState The saved instance state for the activity.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_list);

        // Initialize user and controller
        user = new User("default_user");
        controller = new TodoListController(user);

        // Load saved points and tasks from SharedPreferences
        user.setPoints(loadPoints());
        tasks = loadTasks();

        // Bind UI elements
        pointsTextView = findViewById(R.id.pointsTextView);
        inputEditText = findViewById(R.id.inputEditText);
        Button addButton = findViewById(R.id.addButton);
        Button backButton = findViewById(R.id.backButton);
        listView = findViewById(R.id.List);

        // Set up the adapter for the ListView
        adapter = new CustomAdapter(this, tasks, controller);
        listView.setAdapter(adapter);

        // Display initial points
        updatePointsDisplay();

        // Handle the Add button to add tasks to the todo list
        addButton.setOnClickListener(view -> {
            String taskName = inputEditText.getText().toString().trim();
            if (!taskName.isEmpty()) {
                addTask(taskName); // Add task if input is not empty
            }
        });

        // Handle the Back button to navigate to the main menu
        backButton.setOnClickListener(v -> {
            saveTasks(); // Save tasks to persistent storage
            savePoints(); // Save user points to persistent storage
            Intent intent = new Intent(this, MainMenuActivity.class);
            startActivity(intent); // Navigate to MainMenuActivity
            finish(); // Close the current activity
        });
    }

    /**
     * Adds a new task to the todo list and updates the ListView.
     * <p>
     * This method also clears the input field and saves the updated task list.
     *
     * @param taskName The name of the task to add.
     */
    private void addTask(String taskName) {
        Task newTask = new Task(taskName);
        tasks.add(newTask); // Add the task to the list
        adapter.notifyDataSetChanged(); // Refresh the ListView
        inputEditText.setText(""); // Clear the input field
        saveTasks(); // Save updated task list to persistent storage
    }

    /**
     * Updates the points displayed in the UI.
     * This method retrieves the current points from the controller
     * and updates the TextView.
     */
    public void updatePointsDisplay() {
        pointsTextView.setText("Points: " + controller.getPoints());
    }

    /**
     * Saves the current list of tasks to SharedPreferences.
     * Tasks are stored as a set of strings representing their names.
     */
    public void saveTasks() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Set<String> taskNames = new HashSet<>();
        for (Task task : tasks) {
            taskNames.add(task.getName());
        }
        editor.putStringSet(TASKS_KEY, taskNames); // Save the task names
        editor.apply();
    }

    /**
     * Loads the list of tasks from SharedPreferences.
     * If no tasks are saved, an empty list is returned.
     *
     * @return The list of tasks loaded from SharedPreferences.
     */
    private ArrayList<Task> loadTasks() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        Set<String> taskNames = sharedPreferences.getStringSet(TASKS_KEY, new HashSet<>());
        ArrayList<Task> loadedTasks = new ArrayList<>();
        for (String taskName : taskNames) {
            loadedTasks.add(new Task(taskName)); // Recreate Task objects
        }
        return loadedTasks;
    }

    /**
     * Saves the user's points to SharedPreferences.
     */
    public void savePoints() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(POINTS_KEY, controller.getPoints()); // Save the user's points
        editor.apply();
    }

    /**
     * Loads the user's points from SharedPreferences.
     * If no points are saved, the default value is 0.
     *
     * @return The user's points loaded from SharedPreferences.
     */
    private int loadPoints() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        return sharedPreferences.getInt(POINTS_KEY, 0); // Default to 0 points
    }

    /**
     * Saves a completed task to the history in SharedPreferences.
     * This method adds the task to a history set and saves it persistently.
     *
     * @param task The task to save to the history.
     */
    public void saveToHistory(Task task) {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Set<String> historySet = sharedPreferences.getStringSet("history_tasks", new HashSet<>());
        historySet.add(task.getName()); // Add task to the history set
        editor.putStringSet("history_tasks", historySet); // Save the updated history
        editor.apply();
    }

    /**
     * Updates the points display when the activity resumes.
     * This ensures the points shown are accurate after returning to the activity.
     */
    @Override
    protected void onResume() {
        super.onResume();
        user.setPoints(loadPoints()); // Load the latest points
        updatePointsDisplay(); // Refresh the UI
    }
}
