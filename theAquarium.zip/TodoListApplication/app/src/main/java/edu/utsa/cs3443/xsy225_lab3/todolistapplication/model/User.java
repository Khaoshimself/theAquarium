package edu.utsa.cs3443.xsy225_lab3.todolistapplication.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Model representing a user and their associated data.
 * The User object stores information like the username, points earned,
 * and the list of completed tasks.
 */
public class User {
    private String username;
    private int points;
    private List<Task> completedTasks;

    /**
     * Constructor for User.
     * @param username The username of the user.
     */
    public User(String username) {
        this.username = username;
        this.points = 0; // Default points
        this.completedTasks = new ArrayList<>();
    }

    /**
     * Gets the username of the user.
     * @return The username.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the username of the user.
     * @param username The new username.
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Gets the user's current points.
     * @return The points.
     */
    public int getPoints() {
        return points;
    }

    /**
     * Sets the user's points.
     * @param points The points to set.
     */
    public void setPoints(int points) {
        this.points = points;
    }

    /**
     * Adds points to the user's current total.
     * @param pointsToAdd The number of points to add.
     */
    public void addPoints(int pointsToAdd) {
        this.points += pointsToAdd;
    }

    /**
     * Gets the user's list of completed tasks.
     * @return The list of completed tasks.
     */
    public List<Task> getCompletedTasks() {
        return completedTasks;
    }
}
