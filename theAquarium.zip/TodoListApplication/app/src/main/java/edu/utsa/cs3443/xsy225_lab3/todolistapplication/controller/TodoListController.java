package edu.utsa.cs3443.xsy225_lab3.todolistapplication.controller;

import edu.utsa.cs3443.xsy225_lab3.todolistapplication.model.Task;
import edu.utsa.cs3443.xsy225_lab3.todolistapplication.model.User;

/**
 * Controller for managing task-related operations in the todo list.
 * This class acts as the mediator between the model (tasks and user data)
 * and the view, ensuring proper handling of business logic.
 */
public class TodoListController {
    private final User user;

    /**
     * Constructor for TodoListController.
     * @param user The user associated with the todo list.
     */
    public TodoListController(User user) {
        this.user = user;
    }

    /**
     * Adds a task to the user's completed task list.
     * @param taskName The name of the task to add.
     */
    public void addTask(String taskName) {
        Task task = new Task(taskName);
        user.getCompletedTasks().add(task);
    }

    /**
     * Marks a task as completed and awards points to the user.
     * @param task The task to complete.
     */
    public void completeTask(Task task) {
        task.markAsCompleted(); // Mark the task as completed
        user.addPoints(500); // Award points for completing the task
        user.getCompletedTasks().remove(task); // Optional: Remove task from active to history
    }

    /**
     * Retrieves the user's current points.
     * @return The user's points.
     */
    public int getPoints() {
        return user.getPoints();
    }
}
