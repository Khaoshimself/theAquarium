package edu.utsa.cs3443.xsy225_lab3.todolistapplication.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

import edu.utsa.cs3443.xsy225_lab3.todolistapplication.R;
import edu.utsa.cs3443.xsy225_lab3.todolistapplication.controller.TodoListController;
import edu.utsa.cs3443.xsy225_lab3.todolistapplication.model.Task;
import edu.utsa.cs3443.xsy225_lab3.todolistapplication.view.TodoListActivity;

/**
 * CustomAdapter manages the display and interactions for tasks in a ListView.
 * This adapter provides a way to bind task data to views for display and handle
 * task-specific actions like deletion and completion.
 */
public class CustomAdapter extends ArrayAdapter<Task> {

    private final TodoListController controller;

    /**
     * Constructor for CustomAdapter.
     * @param context The context of the activity using this adapter.
     * @param tasks The list of tasks to display.
     * @param controller The controller to handle task operations.
     */
    public CustomAdapter(Context context, List<Task> tasks, TodoListController controller) {
        super(context, 0, tasks);
        this.controller = controller;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        // Get the task at the current position
        Task task = getItem(position);

        // Bind UI elements
        TextView taskName = convertView.findViewById(R.id.itemTextView);
        Button deleteButton = convertView.findViewById(R.id.deleteButton);
        Button completeButton = convertView.findViewById(R.id.CompleteBtn);

        // Set task name
        taskName.setText(task.getName());

        // Handle Delete button click
        deleteButton.setOnClickListener(v -> {
            remove(task); // Remove the task from the adapter's data source
            notifyDataSetChanged(); // Refresh the ListView
            ((TodoListActivity) getContext()).saveTasks(); // Save updated tasks
        });

        // Handle Complete button click
        completeButton.setOnClickListener(v -> {
            controller.completeTask(task); // Mark task as completed and award points
            ((TodoListActivity) getContext()).savePoints(); // Save updated points
            ((TodoListActivity) getContext()).saveToHistory(task); // Save task to history
            ((TodoListActivity) getContext()).updatePointsDisplay(); // Update points display
            remove(task); // Remove the task from the adapter's data source
            notifyDataSetChanged(); // Refresh the ListView
            ((TodoListActivity) getContext()).saveTasks(); // Save updated tasks
        });

        return convertView;
    }
}
