package edu.utsa.cs3443.xsy225_lab3.todolistapplication.controller;

import edu.utsa.cs3443.xsy225_lab3.todolistapplication.model.User;

/**
 * Controller for managing user-related actions and operations.
 * This class provides methods for handling user-specific logic, such as
 * retrieving user details, updating points, and managing completed tasks.
 */
public class UserController {
    private final User user;

    /**
     * Constructor for UserController.
     * @param user The user associated with this controller.
     */
    public UserController(User user) {
        this.user = user;
    }

    /**
     * Gets the user's current points.
     * @return The total points of the user.
     */
    public int getPoints() {
        return user.getPoints();
    }

    /**
     * Sets the user's points.
     * @param points The new points value for the user.
     */
    public void setPoints(int points) {
        user.setPoints(points);
    }

    /**
     * Adds points to the user's current total.
     * @param pointsToAdd The number of points to add.
     */
    public void addPoints(int pointsToAdd) {
        user.addPoints(pointsToAdd);
    }

    /**
     * Gets the user's username.
     * @return The username of the user.
     */
    public String getUsername() {
        return user.getUsername();
    }

    /**
     * Sets a new username for the user.
     * @param username The new username for the user.
     */
    public void setUsername(String username) {
        user.setUsername(username);
    }
}
