package edu.utsa.cs3443.xsy225_lab3.todolistapplication.view;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import edu.utsa.cs3443.xsy225_lab3.todolistapplication.R;

/**
 * MainMenuActivity serves as the central navigation hub for the application.
 * Users can navigate to Todo List, History, or Profile, and logout from this screen.
 */
public class MainMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        // Always display "Welcome"
        TextView welcomeTextView = findViewById(R.id.welcomeTextView);
        welcomeTextView.setText("Welcome");

        // Bind buttons
        Button todoListButton = findViewById(R.id.button2);
        Button historyButton = findViewById(R.id.button3);
        Button profileButton = findViewById(R.id.button4);
        Button logoutButton = findViewById(R.id.buttonLogout);

        // Set up button listeners
        todoListButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, TodoListActivity.class);
            startActivity(intent);
        });

        historyButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, HistoryActivity.class);
            startActivity(intent);
        });

        profileButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, UserProfileActivity.class);
            startActivity(intent);
        });

        logoutButton.setOnClickListener(v -> {
            SharedPreferences sharedPreferences = getSharedPreferences("shared_prefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.clear();
            editor.apply();

            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }
}
