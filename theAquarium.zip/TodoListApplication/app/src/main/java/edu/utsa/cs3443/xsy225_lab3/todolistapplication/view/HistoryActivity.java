package edu.utsa.cs3443.xsy225_lab3.todolistapplication.view;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import edu.utsa.cs3443.xsy225_lab3.todolistapplication.R;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * Activity to display the history of completed tasks.
 * Tasks are retrieved from SharedPreferences and displayed in a ListView.
 */
public class HistoryActivity extends AppCompatActivity {
    private ListView historyListView;
    private ArrayAdapter<String> historyAdapter;
    private ArrayList<String> historyItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        // Bind ListView
        historyListView = findViewById(R.id.historyListView);

        // Load history items
        historyItems = loadHistory();

        // Set up the adapter
        historyAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, historyItems);
        historyListView.setAdapter(historyAdapter);
    }

    /**
     * Loads the completed task history from SharedPreferences.
     * @return A list of completed task names.
     */
    private ArrayList<String> loadHistory() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared_prefs", MODE_PRIVATE);
        Set<String> historySet = sharedPreferences.getStringSet("history_tasks", new HashSet<>());
        return new ArrayList<>(historySet);
    }
}
